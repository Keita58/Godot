import 'package:flutter/material.dart';
import 'package:harry_potter/providers/Preferences.dart';
import 'package:harry_potter/screens/Character_create.dart';
import 'package:harry_potter/screens/character_detail.dart';
import 'package:harry_potter/screens/hogwarts_data.dart';
import 'package:provider/provider.dart';
import '../models/character.dart';

class CharacterList extends StatefulWidget {
  CharacterList({super.key});

  @override
  State<CharacterList> createState() => _CharacterListState();
}

class _CharacterListState extends State<CharacterList> {

  @override
  Widget build(BuildContext context) {

    return Consumer<Preferences>(
      builder: (context, pref, child) {
        return Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.purple,
            title: const Text("Welcome to Hogwarts", style: TextStyle(color:Colors.white),),
            actions: [Switch(value: pref.showSubtitles!, onChanged: (value){
                pref.setShowSubtitles(value);
            })],
          ),
          body: Consumer<HogwartsData>(
            builder: (BuildContext context, HogwartsData data, child) {
              debugPrint("characterList"+data.characters.length.toString());
              return ListView(
                children: [
                  for (Character character in data.characters)
                    Padding(
                      padding: const EdgeInsets.all(3.0),
                      child: ListTile(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => CharacterDetail(id: character.id,)
                              )
                          );
                        },
                        leading: Hero(tag: character.name, // Posem el mateix "codi" als dos costats
                            child: Image.network(character.url)),
                        title: Text(character.name),
                        subtitle: pref.showSubtitles! ? Text(character.reviews.toString()) : null,
                        trailing: Text(character.id.toString()),
                      ),
                    )
                ],
              );
            },
          ),
          floatingActionButton: Consumer<HogwartsData>(
            builder: (context, pref, child) {
              return FloatingActionButton(
                onPressed: () async {
                  final ch= await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Formulari()),
                  );
                  if (ch!=null) {
                    pref.addCharacter(ch);
                  }
                },
                child: Icon(Icons.add),
              );
            }
          ) ,
        );
      }
    );
  }
}
