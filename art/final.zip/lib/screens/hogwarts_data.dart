import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';

import '../models/character.dart';

class HogwartsData extends ChangeNotifier {

  DatabaseReference ref = FirebaseDatabase.instance.ref("character");


  Future<void> llegir() async {
    try {
      final snapshot = await ref.get();

      characters.clear();

      if (snapshot.exists) {
        for (var childSnapshot in snapshot.children) {
          final Map<dynamic, dynamic>? characterData =
          childSnapshot.value as Map<dynamic, dynamic>?;

          if (characterData != null) {
            Character character = Character(
              name: characterData['name'] ?? '',
              url: characterData['url'] ?? '',
              strength: characterData['strength'] ?? 0,
              speed: characterData['speed'] ?? 0,
              magic: characterData['magic'] ?? 0,
              id: characterData['id'] ?? 0,
            );

            characters.add(character);
          }
        }
        notifyListeners();
        await Future.delayed(Duration(microseconds: 500));

      } else {
        print('no hay pj en la db');
      }
    } catch (e) {
      print('error $e');
    }
  }

  HogwartsData(){
    llegir();
  }

  List<Character> characters = [
    Character(
      name: "Harry Potter",
      url:
      "https://static.wikia.nocookie.net/esharrypotter/images/8/8d/PromoHP7_Harry_Potter.jpg/revision/latest/scale-to-width-down/1200?cb=20160903184919",
      strength: 6,
      speed: 8,
      magic: 9,
      id:1
      // stars: 5,
      // reviews:30,
    ),
    Character(
      name: "Hermione Granger",
      url:
      "https://static.wikia.nocookie.net/warnerbros/images/3/3e/Hermione.jpg/revision/latest/scale-to-width-down/399?cb=20120729103114&path-prefix=es",
      strength: 8,
      speed: 10,
      magic: 10,
      id:2
      // stars: 3,
      // reviews:50,
    ),
    Character(
      name: "Ron Weasly",
      url:
      "https://static.wikia.nocookie.net/esharrypotter/images/6/69/P7_promo_Ron_Weasley.jpg/revision/latest?cb=20150523213430",
      strength: 4,
      speed: 6,
      magic: 7,
      id:3
      // stars: 5,
      // reviews:30,
    ),
  ];

  void addRating(Character character, int value){
    character.addRating(value);
    debugPrint("añadocharacter"+characters.last.name);
    notifyListeners();
  }

  Character? getCharacterFromId(int id){
    for (Character character in characters){
      if (character.id == id) return character;
    }
    return null;
  }



   void addCharacter(Character character)  {
    characters.add(character);
    afegirDatabase(character);
    debugPrint(character.name);
    notifyListeners();
    debugPrint("añadocharacter"+characters.last.name);
  }

  Future<void> afegirDatabase(Character character) async {
   final ref2= ref.child(
        character.name
    );

    debugPrint("Intentando añadir ${character.name} a la BD...");

    await ref2.set({
      "name": character.name,
      "url": character.url,
      "strength": character.strength,
      "magic": character.magic,
      "speed": character.speed,
      "id": character.id
    });

    debugPrint("Personaje ${character.name} añadido con éxito!");
  }

}