import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:harry_potter/models/character.dart';
import 'package:harry_potter/screens/hogwarts_data.dart';
import 'package:provider/provider.dart';

class CharacterCreate extends State<Formulari> {

  final controllerNomCharacter=TextEditingController();
  final controllerImg=TextEditingController();
  final controllerStrength=TextEditingController();
  final controllerSpeed=TextEditingController();
  final controllerMagic=TextEditingController();
  final controllerID=TextEditingController();
  @override
  void dispose() {
    // Clean up the controller when the widget is disposed.
    controllerNomCharacter.dispose();
    controllerImg.dispose();
    controllerStrength.dispose();
    controllerSpeed.dispose();
    controllerMagic.dispose();
    controllerID.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFFF896D8),
        centerTitle: true,
        title: Text("New Character"),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {
            Navigator.pop(
                context
            );
          },
        ),
      ),
      body: Center(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: SizedBox(
                  width: 250,
                  child: TextField(
                    controller: controllerNomCharacter,
                    decoration: InputDecoration(border: OutlineInputBorder(), labelText: 'Nom personatge'),
                  ),
                ),
              ),
              SizedBox(
                width: 250,
                child: TextField(
                  controller: controllerImg,
                  decoration: InputDecoration(border: OutlineInputBorder(), labelText: 'Url de la imatge'),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: SizedBox(
                  width: 250,
                  child: TextField(
                    controller: controllerStrength,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(border: OutlineInputBorder(), labelText: 'Força'),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: SizedBox(
                  width: 250,
                  child: TextField(
                    controller: controllerSpeed,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(border: OutlineInputBorder(), labelText: 'Velocitat'),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: SizedBox(
                  width: 250,
                  child: TextField(
                    controller: controllerMagic,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(border: OutlineInputBorder(), labelText: 'Màgia'),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: SizedBox(
                  width: 250,
                  child: TextField(
                    controller: controllerID,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(border: OutlineInputBorder(), labelText: 'ID'),
                  ),
                ),
              ),
              FilledButton(onPressed: (){
                Character ch  = new Character(name: controllerNomCharacter.text, url: controllerImg.text, magic: int.parse(controllerMagic.text) , strength: int.parse(controllerStrength.text), speed: int.parse(controllerSpeed.text), id: int.parse(controllerID.text));
                Navigator.pop(context, ch);
                //Navigator.pop(context, ch);
              },
                  child: Text("Enviar"))
            ],
          )
      ),
    );
  }
  
}

class Formulari extends StatefulWidget{
  const Formulari({super.key});
  @override
  State<Formulari> createState() => CharacterCreate();

}